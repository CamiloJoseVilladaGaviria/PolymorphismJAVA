/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javapractice01;
/**
 *
 * @author ASUS
 */
public class Gato extends JavaPractice01 {
    Gato() {
        super();
        nombreAnimal = "Pepe";
        clasificacionAnimal = "Gato";
        nombreEspecieAnimal = "Felino";
        edadAnimal = 10;
        ladridoAnimal = "Miau";
        System.out.println(nombreAnimal);
        System.out.println(clasificacionAnimal);
        System.out.println(nombreEspecieAnimal);
        System.out.println(edadAnimal);
        System.out.println(ladridoAnimal);
}
}
