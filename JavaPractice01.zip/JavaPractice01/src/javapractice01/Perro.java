/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javapractice01;

/**
 *
 * @author ASUS
 */
public class Perro extends JavaPractice01 {
    Perro() {
        super();
        nombreAnimal = "Firulais";
        clasificacionAnimal = "Perro";
        nombreEspecieAnimal = "Canino";
        edadAnimal = 12;
        ladridoAnimal = "Guau";
        System.out.println(nombreAnimal);
        System.out.println(clasificacionAnimal);
        System.out.println(nombreEspecieAnimal);
        System.out.println(edadAnimal);
        System.out.println(ladridoAnimal);
    }
}
